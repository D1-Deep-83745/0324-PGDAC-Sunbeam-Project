package com.example.demo.service;

import com.example.demo.entity.TransactionDetails;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.TransactionDetailsRepository;
import com.example.demo.service.TransactionDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionDetailsServiceImpl implements TransactionDetailsService {

    @Autowired
    private TransactionDetailsRepository transactionDetailsRepository;

    @Override
    public TransactionDetails createTransactionDetails(TransactionDetails transactionDetails) {
        return transactionDetailsRepository.save(transactionDetails);
    }

    @Override
    public TransactionDetails getTransactionDetailsById(Long id) {
        return transactionDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid TransactionDetails"));
    }

    @Override
    public List<TransactionDetails> getAllTransactionDetails() {
        return transactionDetailsRepository.findAll();
    }

    @Override
    public TransactionDetails updateTransactionDetails(Long id, TransactionDetails transactionDetails) {
        TransactionDetails existingTransactionDetails = getTransactionDetailsById(id);
        existingTransactionDetails.setAmount(transactionDetails.getAmount());
        existingTransactionDetails.setTransactionDate(transactionDetails.getTransactionDate());
        existingTransactionDetails.setPaymentMethod(transactionDetails.getPaymentMethod());
        existingTransactionDetails.setPaymentStatus(transactionDetails.getPaymentStatus());
        return transactionDetailsRepository.save(existingTransactionDetails);
    }

    @Override
    public void deleteTransactionDetails(Long id) {
        TransactionDetails transactionDetails = getTransactionDetailsById(id);
        transactionDetailsRepository.delete(transactionDetails);
    }
}
