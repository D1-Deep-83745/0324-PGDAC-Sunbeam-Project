package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class OrderDetailsDTO extends BaseDTO {
    private Long userId;
    private Date orderDate;
    private double totalAmount;
    private Long adminId;
    private List<OrderItemDTO> orderItems;
}