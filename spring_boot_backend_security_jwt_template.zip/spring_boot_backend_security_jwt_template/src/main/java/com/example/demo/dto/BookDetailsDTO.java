package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class BookDetailsDTO extends BaseDTO {
    private String title;
    private String description;
    private double price;
    private Date publishDate;
    private Long categoryId;
    private Long authorId;
    private Long publisherId;
    private Long adminId;
}