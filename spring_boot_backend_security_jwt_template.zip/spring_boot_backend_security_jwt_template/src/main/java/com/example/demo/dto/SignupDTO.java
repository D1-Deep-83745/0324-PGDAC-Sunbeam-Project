package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class SignupDTO {
    private String email;
    private String firstName;
    private String lastName;
    private String phone;
    private String gender;
    private Date dob;
    private String password;
}