package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class SigninResponseDTO {
    private String token;

    public SigninResponseDTO(String token) {
        this.token = token;
    }
}