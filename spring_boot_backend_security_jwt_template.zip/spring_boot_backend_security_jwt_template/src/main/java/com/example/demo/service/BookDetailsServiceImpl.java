package com.example.demo.service;

import com.example.demo.entity.BookDetails;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.BookDetailsRepository;
import com.example.demo.service.BookDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookDetailsServiceImpl implements BookDetailsService {

    @Autowired
    private BookDetailsRepository bookDetailsRepository;

    @Override
    public BookDetails createBookDetails(BookDetails bookDetails) {
        return bookDetailsRepository.save(bookDetails);
    }

    @Override
    public BookDetails getBookDetailsById(Long id) {
        return bookDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid BookDetails"));
    }

    @Override
    public List<BookDetails> getAllBookDetails() {
        return bookDetailsRepository.findAll();
    }

    @Override
    public BookDetails updateBookDetails(Long id, BookDetails bookDetails) {
        BookDetails existingBookDetails = getBookDetailsById(id);
        existingBookDetails.setTitle(bookDetails.getTitle());
        existingBookDetails.setDescription(bookDetails.getDescription());
        existingBookDetails.setPrice(bookDetails.getPrice());
        existingBookDetails.setPublishDate(bookDetails.getPublishDate());
        existingBookDetails.setCategory(bookDetails.getCategory());
        existingBookDetails.setAuthor(bookDetails.getAuthor());
        existingBookDetails.setPublisher(bookDetails.getPublisher());
        return bookDetailsRepository.save(existingBookDetails);
    }

    @Override
    public void deleteBookDetails(Long id) {
        BookDetails bookDetails = getBookDetailsById(id);
        bookDetailsRepository.delete(bookDetails);
    }
}
