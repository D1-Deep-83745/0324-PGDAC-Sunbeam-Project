package com.example.demo.controller;

import com.example.demo.dto.ApiResponseDTO;
import com.example.demo.entity.Address;
import com.example.demo.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @GetMapping
    public ApiResponseDTO getAllAddresses() {
        List<Address> addresses = addressService.getAllAddresses();
        return new ApiResponseDTO(true, "Addresses retrieved successfully", addresses);
    }

    @GetMapping("/{id}")
    public ApiResponseDTO getAddressById(@PathVariable Long id) {
        Address address = addressService.getAddressById(id);
        return new ApiResponseDTO(true, "Address retrieved successfully", address);
    }

    @PostMapping
    public ApiResponseDTO createAddress(@RequestBody Address address) {
        Address createdAddress = addressService.createAddress(address);
        return new ApiResponseDTO(true, "Address created successfully", createdAddress);
    }

    @PutMapping("/{id}")
    public ApiResponseDTO updateAddress(@PathVariable Long id, @RequestBody Address addressDetails) {
        Address updatedAddress = addressService.updateAddress(id, addressDetails);
        return new ApiResponseDTO(true, "Address updated successfully", updatedAddress);
    }

    @DeleteMapping("/{id}")
    public ApiResponseDTO deleteAddress(@PathVariable Long id) {
        addressService.deleteAddress(id);
        return new ApiResponseDTO(true, "Address deleted successfully", null);
    }
}