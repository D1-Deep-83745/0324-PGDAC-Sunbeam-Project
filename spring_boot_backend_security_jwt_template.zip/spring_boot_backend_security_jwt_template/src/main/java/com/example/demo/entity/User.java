package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(length = 25,nullable = false)
    private String firstName;
    
    @Column(length = 25 , nullable = false)
    private String lastName;

    private String phone;

    private String gender;

    @Temporal(TemporalType.DATE)
    private Date dob;
    
    @Enumerated(EnumType.STRING)
    @Column(length = 8)
    private Role userRole;
    // Additional fields and relationships
}
