package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class AddressDTO extends BaseDTO {
    private Long userId;
    private String street;
    private String city;
    private String state;
    private String zipCode;
    private String country;
}