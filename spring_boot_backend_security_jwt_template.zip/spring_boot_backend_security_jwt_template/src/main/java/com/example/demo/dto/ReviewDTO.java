package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class ReviewDTO extends BaseDTO {
    private Long bookId;
    private Long userId;
    private int rating;
    private String comment;
    private Date reviewDate;
    private Long adminId;
}