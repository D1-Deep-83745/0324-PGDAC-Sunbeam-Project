package com.example.demo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
@Data
@NoArgsConstructor
public class UserDetailsDTO extends BaseDTO {
    private String email;
    private String name;
    private String phone;
    private String gender;
    private Date dob;
    private List<AddressDTO> addresses;
}