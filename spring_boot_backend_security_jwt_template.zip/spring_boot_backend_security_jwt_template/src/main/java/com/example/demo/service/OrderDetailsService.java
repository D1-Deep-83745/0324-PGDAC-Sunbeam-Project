package com.example.demo.service;

import com.example.demo.entity.OrderDetails;
import java.util.List;

public interface OrderDetailsService {
    OrderDetails createOrderDetails(OrderDetails orderDetails);
    OrderDetails getOrderDetailsById(Long id);
    List<OrderDetails> getAllOrderDetails();
    OrderDetails updateOrderDetails(Long id, OrderDetails orderDetails);
    void deleteOrderDetails(Long id);
}
