package com.example.demo.entity;
public enum Role {
   CUSTOMER,SALES,ADMIN
}
