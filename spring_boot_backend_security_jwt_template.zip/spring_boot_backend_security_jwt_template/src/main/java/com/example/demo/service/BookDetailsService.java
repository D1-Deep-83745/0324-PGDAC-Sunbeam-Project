package com.example.demo.service;

import com.example.demo.entity.BookDetails;
import java.util.List;

public interface BookDetailsService {
    BookDetails createBookDetails(BookDetails bookDetails);
    BookDetails getBookDetailsById(Long id);
    List<BookDetails> getAllBookDetails();
    BookDetails updateBookDetails(Long id, BookDetails bookDetails);
    void deleteBookDetails(Long id);
}
