package com.example.demo.service;

import com.example.demo.entity.OrderDetails;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.OrderDetailsRepository;
import com.example.demo.service.OrderDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {

    @Autowired
    private OrderDetailsRepository orderDetailsRepository;

    @Override
    public OrderDetails createOrderDetails(OrderDetails orderDetails) {
        return orderDetailsRepository.save(orderDetails);
    }

    @Override
    public OrderDetails getOrderDetailsById(Long id) {
        return orderDetailsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid OrderDetails"));
    }

    @Override
    public List<OrderDetails> getAllOrderDetails() {
        return orderDetailsRepository.findAll();
    }

    @Override
    public OrderDetails updateOrderDetails(Long id, OrderDetails orderDetails) {
        OrderDetails existingOrderDetails = getOrderDetailsById(id);
        existingOrderDetails.setOrderDate(orderDetails.getOrderDate());
        existingOrderDetails.setTotalAmount(orderDetails.getTotalAmount());
        existingOrderDetails.setOrderItems(orderDetails.getOrderItems());
        return orderDetailsRepository.save(existingOrderDetails);
    }

    @Override
    public void deleteOrderDetails(Long id) {
        OrderDetails orderDetails = getOrderDetailsById(id);
        orderDetailsRepository.delete(orderDetails);
    }
}
