package com.example.demo.controller;

import com.example.demo.dto.SigninRequestDTO;
import com.example.demo.dto.SignupDTO;
import com.example.demo.entity.User;
import com.example.demo.dto.ApiResponseDTO;
import com.example.demo.dto.SigninResponseDTO;
import com.example.demo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/signin")
    public ResponseEntity<SigninResponseDTO> authenticateUser(@RequestBody SigninRequestDTO signinRequest) {
        return ResponseEntity.ok(authService.signin(signinRequest));
    }

    @PostMapping("/signup")
    public ResponseEntity<User> registerUser(@RequestBody SignupDTO signupDTO) {
        return ResponseEntity.ok(authService.signup(signupDTO));
    }
}
