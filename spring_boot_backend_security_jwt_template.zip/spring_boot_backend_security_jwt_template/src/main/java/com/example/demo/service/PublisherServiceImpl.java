package com.example.demo.service;

import com.example.demo.entity.Publisher;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.PublisherRepository;
import com.example.demo.service.PublisherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PublisherServiceImpl implements PublisherService {

    @Autowired
    private PublisherRepository publisherRepository;

    @Override
    public Publisher createPublisher(Publisher publisher) {
        return publisherRepository.save(publisher);
    }

    @Override
    public Publisher getPublisherById(Long id) {
        return publisherRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid Publisher"));
    }

    @Override
    public List<Publisher> getAllPublishers() {
        return publisherRepository.findAll();
    }

    @Override
    public Publisher updatePublisher(Long id, Publisher publisher) {
        Publisher existingPublisher = getPublisherById(id);
        existingPublisher.setPublisherName(publisher.getPublisherName());
        return publisherRepository.save(existingPublisher);
    }

    @Override
    public void deletePublisher(Long id) {
        Publisher publisher = getPublisherById(id);
        publisherRepository.delete(publisher);
    }
}
