package com.example.demo.service;

import com.example.demo.entity.Publisher;
import java.util.List;

public interface PublisherService {
    Publisher createPublisher(Publisher publisher);
    Publisher getPublisherById(Long id);
    List<Publisher> getAllPublishers();
    Publisher updatePublisher(Long id, Publisher publisher);
    void deletePublisher(Long id);
}
