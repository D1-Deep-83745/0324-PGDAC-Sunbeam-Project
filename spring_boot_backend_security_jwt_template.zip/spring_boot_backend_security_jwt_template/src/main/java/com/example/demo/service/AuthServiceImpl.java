package com.example.demo.service;

import com.example.demo.dto.SigninRequestDTO;
import com.example.demo.dto.SigninResponseDTO;
import com.example.demo.dto.SignupDTO;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtTokenProvider;
import com.example.demo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserRepository userRepository;

    @Override
    public SigninResponseDTO signin(SigninRequestDTO signinRequestDTO) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        signinRequestDTO.getUsername(),
                        signinRequestDTO.getPassword()
                )
        );

        String jwt = tokenProvider.generateToken(authentication);
        return new SigninResponseDTO(jwt);
    }

    @Override
    public User signup(SignupDTO signupDTO) {
        User user = new User();
        user.setEmail(signupDTO.getEmail());
        user.setFirstName(signupDTO.getFirstName());
        user.setLastName(signupDTO.getLastName());
        user.setPhone(signupDTO.getPhone());
        user.setGender(signupDTO.getGender());
        user.setDob(signupDTO.getDob());
        user.setPassword(passwordEncoder.encode(signupDTO.getPassword()));

        return userRepository.save(user);
    }
}
