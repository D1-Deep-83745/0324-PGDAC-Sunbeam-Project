package com.example.demo.service;

import com.example.demo.entity.Address;
import java.util.List;

public interface AddressService {
    Address createAddress(Address address);
    Address getAddressById(Long id);
    List<Address> getAllAddresses();
    Address updateAddress(Long id, Address address);
    void deleteAddress(Long id);
}
