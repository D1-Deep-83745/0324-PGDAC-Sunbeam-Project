package com.example.demo.service;

import com.example.demo.dto.SigninRequestDTO;
import com.example.demo.dto.SigninResponseDTO;
import com.example.demo.dto.SignupDTO;
import com.example.demo.entity.User;

public interface AuthService {
    SigninResponseDTO signin(SigninRequestDTO signinRequestDTO);
    User signup(SignupDTO signupDTO);
}
