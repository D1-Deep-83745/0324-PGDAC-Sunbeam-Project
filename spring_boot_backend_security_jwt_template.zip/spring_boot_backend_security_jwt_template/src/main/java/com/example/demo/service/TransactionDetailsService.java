package com.example.demo.service;

import com.example.demo.entity.TransactionDetails;
import java.util.List;

public interface TransactionDetailsService {
    TransactionDetails createTransactionDetails(TransactionDetails transactionDetails);
    TransactionDetails getTransactionDetailsById(Long id);
    List<TransactionDetails> getAllTransactionDetails();
    TransactionDetails updateTransactionDetails(Long id, TransactionDetails transactionDetails);
    void deleteTransactionDetails(Long id);
}
